/* --- header file : subtract.h ---*/ 

int subtract(int, int);


