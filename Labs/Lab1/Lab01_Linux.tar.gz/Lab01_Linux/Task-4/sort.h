
void bubbleSort(int*  , int );
void quickSort( int*, int , int );
int partition( int*, int , int );
