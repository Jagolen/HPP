double ffff(const double * a, int N);
