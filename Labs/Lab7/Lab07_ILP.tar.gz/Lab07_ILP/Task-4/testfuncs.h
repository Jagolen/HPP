
double f_std(const double * a, int N);

double f_opt(const double * a, int N);

