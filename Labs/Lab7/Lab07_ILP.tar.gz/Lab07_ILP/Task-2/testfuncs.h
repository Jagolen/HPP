
void f_std(const double * a, const double * b, double * c, int N);

void f_opt(const double * a, const double * b, double * c, int N);

