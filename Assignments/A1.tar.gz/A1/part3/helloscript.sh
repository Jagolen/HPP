echo Hej hej
echo god dag
echo trevlig helg
echo en rad till